import java.util.Scanner;

public class Login {
    private String username;
    private String password;

    // Method to check if the username meets the format requirements
    public boolean checkUserName(String username) {
        return username.contains("_") && username.length() <= 5;
    }

    // Method to check if the password meets complexity requirements
    public boolean checkPasswordComplexity(String password) {
        return password.length() >= 8 &&
               password.matches(".[A-Z].") &&
               password.matches(".\\d.") &&
               password.matches(".[!@#$%^&()].*");
    }

    // Method to register a new user
    public String registerUser(Scanner scanner) {
        System.out.print("Enter username: ");
        String username = scanner.nextLine();

        if (!checkUserName(username)) {
            return "Username is not correctly formatted, please ensure that your username contains an underscore and is no more than 5 characters in length.";
        }

        System.out.print("Enter password: ");
        String password = scanner.nextLine();

        if (!checkPasswordComplexity(password)) {
            return "Password is not correctly formatted, please ensure that the password contains at least 8 characters, a capital letter, a number, and a special character.";
        }

        this.username = username;
        this.password = password;

        return "User registered successfully.";
    }

    // Method to login with existing credentials
    public boolean loginUser(Scanner scanner) {
        System.out.print("Enter username: ");
        String enteredUsername = scanner.nextLine();

        System.out.print("Enter password: ");
        String enteredPassword = scanner.nextLine();

        return enteredUsername.equals(username) && enteredPassword.equals(password);
    }

    // Method to return login status message
    public String returnLoginStatus(boolean loggedIn) {
        if (loggedIn) {
            return "Welcome to the system!";
        } else {
            return "Username or password incorrect, please try again.";
        }
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Login login = new Login();

        System.out.println(login.registerUser(scanner));
        boolean loggedIn = login.loginUser(scanner);
        System.out.println(login.returnLoginStatus(loggedIn));

        scanner.close();
    }
}

