 package registrationandlogin;
import java.util.Scanner;

public class RegistrationAndLogin{
    private String registeredUsername;
    private String registeredPassword;
    private String firstName;
    private String lastName;

    public String registerUser(String username, String password, String firstName, String lastName) {
        if (!checkUserName(username)) {
            return "Username is not correctly formatted, please ensure that your username contains an underscore and is no more than 5 characters in length.";
        }

        if (!checkPasswordComplexity(password)) {
            return "Password is not correctly formatted, please ensure that the password contains at least 8 characters, a capital letter, a number, and a special character.";
        }

        this.registeredUsername = username;
        this.registeredPassword = password;
        this.firstName = firstName;
        this.lastName = lastName;
        return "User registered successfully.";
    }

    public boolean loginUser(String username, String password) {
        return username.equals(registeredUsername) && password.equals(registeredPassword);
    }

    public String returnLoginStatus(boolean isLoggedIn) {
        if (isLoggedIn) {
            return "Welcome " + firstName + " " + lastName + ", it is great to see you again.";
        } else {
            return "Username or password incorrect, please try again";
        }
    }

    public boolean checkUserName(String username) {
        return username.contains("_") && username.length() <= 5;
    }
    public boolean checkPasswordComplexity(String password) {
    // Password complexity check
    return password.length() >= 8 && 
           password.matches(".*[A-Z].*") && 
           password.matches(".*\\d.*") && 
           password.matches(".*[!@#$%^&()].*");
}

       public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        RegistrationAndLogin login = new RegistrationAndLogin();

        System.out.println("Enter username");
        String username = scanner.nextLine();

        System.out.println("Enter password");
        String password = scanner.nextLine();

        System.out.println("Enter first name:");
        String firstName = scanner.nextLine();

        System.out.println("Enter last name:");
        String lastName = scanner.nextLine();

        String registrationResult = login.registerUser(username, password, firstName, lastName);
        System.out.println(registrationResult);

        System.out.println("Enter username for login:");
        String loginUsername = scanner.nextLine();

        System.out.println("Enter password for login:");
        String loginPassword = scanner.nextLine();

        boolean isLoggedIn = login.loginUser(loginUsername, loginPassword);
        String loginStatus = login.returnLoginStatus(isLoggedIn);
        System.out.println(loginStatus);

        scanner.close();
    }
}